# example data from the built-in data set "mtcars"
x = mtcars$wt
y = mtcars$drat
# prepare plot, fit model, get predictions,
# add lines for confidence limits and regression line, add points
plot(y~x,type="n")
m = lm(y~x)
wx = par("usr")[1:2]
new.x = seq(wx[1],wx[2],len=100)
pred = predict(m, new=data.frame(x=new.x), interval="conf")
lines(new.x,pred[,"fit"],lwd=2)
lines(new.x,pred[,"lwr"],lty=3)
lines(new.x,pred[,"upr"],lty=3)
points(x,y,pch=16,col="steelblue")
### alternative: plot confidence band:
plot(y~x,type="n")
polygon(c(new.x,rev(new.x)),c(pred[,"lwr"],rev(pred[,"upr"])),border=NA,col=blues9[3])
lines(new.x,pred[,"fit"],lwd=2,col=blues9[8])
points(x,y,pch=16)
box()

