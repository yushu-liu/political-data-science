library(MASS)
head(survey)
height.survey=survey$Height
mean(height.survey,na.rm= TRUE)

library(plotrix)

set.seed(0815)
x <- 1:10
F <- runif(10,1,2)
L <- runif(10,0,1)
U <- runif(10,2,3)

require(plotrix)
plotCI(x,F,ui=U,li=L)



height.response = na.omit(survey$Height)

sigma = sd(height.response,na.rm = FALSE)

sigma

n = length(height.response)

sem  = sigma/sqrt(n)
sem

cl = 100- 2* sem
cl

E = qnorm(0.986)*sem
E

xbar = mean(height.response)
xbar +c(-E,E)





height.response = na.omit(survey$Height)
n = length(height.response)
s = sd(height.response)
SE = s/sqrt(n)
E = qt(0.975,df=n-1)*SE
E

xbar = mean(height.response0)
xbar + c(-E,E)
