install.packages("rvest")
install.packages("dplyr")


library("rvest")
library("dplyr")

google <- read_html("https://news.google.com/news/headlines?hl=en&gl=US&ned=us")

google %>% html_nodes(".kzAuJ") %>% html_text()
